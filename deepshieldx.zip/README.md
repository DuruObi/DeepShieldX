# DeepShieldX

DeepShieldX is a comprehensive Deepfake Detection & Threat Intelligence Platform. It uses a microservices architecture to detect voice clones, deepfake videos, malicious URLs, and scam messages.

## Architecture

- **Web Dashboard**: Next.js (React) + Tailwind CSS
- **API Gateway**: Node.js (TypeScript) + Express
- **AI Engine**: Python (FastAPI) + PyTorch/Librosa (Stubs included)
- **Database**: PostgreSQL
- **Object Storage**: MinIO (S3 Compatible)
- **Cache**: Redis

## Prerequisites

- Docker & Docker Compose
- Node.js 18+ (for local development)
- Python 3.10+ (for local development)

## Quick Start

1.  **Environment Setup**:
    The project comes with default configuration in `docker-compose.yml`.

2.  **Run with Docker Compose**:
    ```bash
    docker-compose up --build
    ```

3.  **Access Services**:
    - **Web Dashboard**: [http://localhost:3000](http://localhost:3000)
    - **API Gateway**: [http://localhost:8000](http://localhost:8000)
    - **AI Engine Swagger**: [http://localhost:8500/docs](http://localhost:8500/docs)
    - **MinIO Console**: [http://localhost:9001](http://localhost:9001) (User: `minioadmin`, Pass: `minioadmin`)

## Environment Variables

| Variable | Description | Default |
| :--- | :--- | :--- |
| `API_GATEWAY_PORT` | Port for the Gateway | `8000` |
| `AI_ENGINE_URL` | Internal URL for AI Engine | `http://ai-engine:8500` |
| `DATABASE_URL` | Postgres Connection String | `postgres://user:password@postgres:5432/deepshield` |
| `REDIS_URL` | Redis Connection String | `redis://redis:6379` |
| `MINIO_ENDPOINT` | MinIO URL | `minio:9000` |
| `MINIO_ACCESS_KEY` | MinIO Access Key | `minioadmin` |
| `MINIO_SECRET_KEY` | MinIO Secret Key | `minioadmin` |
| `MINIO_BUCKET` | Bucket for uploads | `uploads` |
| `DEV_API_KEY` | Fallback API Key | `dev-secret-123` |

## Development

- **API Gateway**: `cd api-gateway && npm install && npm run dev`
- **AI Engine**: `cd ai-engine && pip install -r requirements.txt && uvicorn app.main:app --reload`
- **Web Dashboard**: `cd web-dashboard && npm install && npm run dev`

## Testing

Run the full test suite via Docker:
```bash
docker-compose run api-gateway npm test
docker-compose run ai-engine pytest
```
