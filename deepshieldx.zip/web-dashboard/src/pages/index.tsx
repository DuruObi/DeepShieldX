import Link from 'next/link';
import { Shield, Lock, Eye } from 'lucide-react';
import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="text-2xl font-bold text-blue-500 flex items-center gap-2">
            <Shield className="w-8 h-8" /> DeepShieldX
        </div>
        <div>
            <Link href="/dashboard" className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700 transition">
                Go to Dashboard
            </Link>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-20 text-center">
        <h1 className="text-5xl font-extrabold mb-6">
            Secure Your Reality Against <span className="text-blue-500">AI Threats</span>
        </h1>
        <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
            DeepShieldX provides enterprise-grade detection for deepfake audio, video, and malicious AI-generated content.
        </p>

        <div className="grid md:grid-cols-3 gap-8 mt-16 text-left">
            <div className="p-6 bg-slate-800 rounded-xl border border-slate-700">
                <Lock className="w-10 h-10 text-blue-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">Voice Protection</h3>
                <p className="text-slate-400">Detect AI-cloned voices in real-time to prevent fraud.</p>
            </div>
            <div className="p-6 bg-slate-800 rounded-xl border border-slate-700">
                <Eye className="w-10 h-10 text-purple-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">Video Forensics</h3>
                <p className="text-slate-400">Analyze pixel-level artifacts to identify face-swaps.</p>
            </div>
            <div className="p-6 bg-slate-800 rounded-xl border border-slate-700">
                <Shield className="w-10 h-10 text-green-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">Threat Intel</h3>
                <p className="text-slate-400">Scan URLs and messages for phishing and social engineering.</p>
            </div>
        </div>
      </main>
    </div>
  );
}
