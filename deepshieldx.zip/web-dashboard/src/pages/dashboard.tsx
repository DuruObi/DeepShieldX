import React, { useState, useEffect } from 'react';
import { Activity, AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react';
import axios from 'axios';

// Mocks
const MOCK_LOGS = [
    { id: 1, type: 'VOICE', status: 'MALICIOUS', time: '10:42 AM', details: 'Voice Clone Detected' },
    { id: 2, type: 'URL', status: 'SAFE', time: '10:40 AM', details: 'google.com' },
    { id: 3, type: 'VIDEO', status: 'SUSPICIOUS', time: '10:35 AM', details: 'High artifact count' },
];

export default function Dashboard() {
  const [stats, setStats] = useState({ scans: 1240, threats: 85, active: 4 });
  
  // In a real app, this would fetch from /v1/admin/stats via axios
  // const apiUrl = process.env.NEXT_PUBLIC_API_URL;

  return (
    <div className="min-h-screen bg-slate-100 flex">
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900 text-white p-6">
            <h2 className="text-2xl font-bold mb-8">DeepShieldX</h2>
            <ul className="space-y-4">
                <li className="text-blue-400 font-semibold">Overview</li>
                <li className="text-slate-400 hover:text-white cursor-pointer">Live Monitor</li>
                <li className="text-slate-400 hover:text-white cursor-pointer">Logs</li>
                <li className="text-slate-400 hover:text-white cursor-pointer">Settings</li>
            </ul>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
            <header className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-slate-800">Security Dashboard</h1>
                <div className="flex items-center gap-2">
                    <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
                    <span className="text-slate-600">System Operational</span>
                </div>
            </header>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex items-center gap-4">
                    <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
                        <Activity className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-slate-500 text-sm">Total Scans (24h)</p>
                        <p className="text-2xl font-bold">{stats.scans}</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex items-center gap-4">
                    <div className="p-3 bg-red-100 text-red-600 rounded-full">
                        <ShieldAlert className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-slate-500 text-sm">Threats Blocked</p>
                        <p className="text-2xl font-bold">{stats.threats}</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex items-center gap-4">
                    <div className="p-3 bg-green-100 text-green-600 rounded-full">
                        <CheckCircle className="w-6 h-6" />
                    </div>
                    <div>
                        <p className="text-slate-500 text-sm">Active Agents</p>
                        <p className="text-2xl font-bold">{stats.active}</p>
                    </div>
                </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                    <h3 className="font-bold text-lg">Recent Detection Logs</h3>
                </div>
                <table className="w-full text-left text-sm text-slate-600">
                    <thead className="bg-slate-50">
                        <tr>
                            <th className="p-4 font-semibold">Time</th>
                            <th className="p-4 font-semibold">Type</th>
                            <th className="p-4 font-semibold">Details</th>
                            <th className="p-4 font-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {MOCK_LOGS.map((log) => (
                            <tr key={log.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
                                <td className="p-4">{log.time}</td>
                                <td className="p-4 font-mono text-xs">{log.type}</td>
                                <td className="p-4">{log.details}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                        log.status === 'MALICIOUS' ? 'bg-red-100 text-red-600' :
                                        log.status === 'SUSPICIOUS' ? 'bg-orange-100 text-orange-600' :
                                        'bg-green-100 text-green-600'
                                    }`}>
                                        {log.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </main>
    </div>
  );
}
