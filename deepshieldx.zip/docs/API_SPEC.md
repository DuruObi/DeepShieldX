# DeepShieldX API Specification v1

Base URL: `http://localhost:8000/v1`

Authentication:
Header `x-api-key: <YOUR_API_KEY>`

## Endpoints

### 1. Check Voice
Detects deepfake audio.
- **POST** `/voice/check`
- **Body**: `multipart/form-data` with `audio` file.
- **Response**:
```json
{
  "score": 0.95,
  "verdict": "likely_deepfake",
  "evidence": { ... }
}
```

### 2. Check Video
Detects video manipulation.
- **POST** `/video/check`
- **Body**: `multipart/form-data` with `video` file.
- **Response**:
```json
{
  "score": 0.12,
  "verdict": "authentic",
  "heatmap_url": "http://minio/..."
}
```

### 3. Inspect URL
Checks for malicious domains.
- **POST** `/url/inspect`
- **Body**: `application/json` -> `{"url": "http://example.com"}`
- **Response**:
```json
{
  "malicious": false,
  "reason": "Safe",
  "confidence": 0.0
}
```
