import { Router, Response } from 'express';
import multer from 'multer';
import { apiKeyAuth, AuthenticatedRequest } from '../middleware/apiKeyAuth';
import { aiClient } from '../services/aiClient';

const router = Router();
const upload = multer({ dest: 'uploads/' }); // Temp storage

// Middleware applied to all routes in this router
router.use(apiKeyAuth as any);

router.post('/voice/check', upload.single('audio'), async (req: AuthenticatedRequest, res: any) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No audio file uploaded' });
    const result = await aiClient.checkVoice(req.file);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/video/check', upload.single('video'), async (req: AuthenticatedRequest, res: any) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No video file uploaded' });
    const result = await aiClient.checkVideo(req.file);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/image/check', upload.single('image'), async (req: AuthenticatedRequest, res: any) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image file uploaded' });
    const result = await aiClient.checkImage(req.file);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/url/inspect', async (req: AuthenticatedRequest, res: any) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL is required' });
    const result = await aiClient.inspectUrl(url);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/message/scan', async (req: AuthenticatedRequest, res: any) => {
  try {
    const { text, source } = req.body;
    if (!text) return res.status(400).json({ error: 'Text is required' });
    const result = await aiClient.scanMessage(text, source || 'unknown');
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

export default router;