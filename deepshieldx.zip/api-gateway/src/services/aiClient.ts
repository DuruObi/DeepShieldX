import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';

const AI_ENGINE_URL = process.env.AI_ENGINE_URL || 'http://localhost:8500';

export interface UploadedFile {
  buffer?: Buffer;
  path?: string;
  originalname: string;
  mimetype?: string;
}

class AiClient {
  private client = axios.create({
    baseURL: AI_ENGINE_URL,
    timeout: 30000, // 30s timeout for heavy processing
  });

  private async postFile(endpoint: string, file: UploadedFile) {
    try {
      const form = new FormData();
      // Handle Multer memory storage (buffer) vs disk storage (path)
      if (file.buffer) {
        form.append('file', file.buffer, { filename: file.originalname });
      } else if (file.path) {
        form.append('file', fs.createReadStream(file.path));
      } else {
         throw new Error('Invalid file object: missing buffer or path');
      }

      const response = await this.client.post(endpoint, form, {
        headers: {
          ...form.getHeaders(),
        },
      });
      return response.data;
    } catch (error: any) {
      console.error(`AI Engine Error [${endpoint}]:`, error.message);
      throw new Error(error.response?.data?.detail || 'AI Engine unavailable');
    }
  }

  private async postJson(endpoint: string, data: any) {
    try {
      const response = await this.client.post(endpoint, data);
      return response.data;
    } catch (error: any) {
      console.error(`AI Engine Error [${endpoint}]:`, error.message);
      throw new Error(error.response?.data?.detail || 'AI Engine unavailable');
    }
  }

  async checkVoice(file: UploadedFile) {
    return this.postFile('/v1/voice/check', file);
  }

  async checkVideo(file: UploadedFile) {
    return this.postFile('/v1/video/check', file);
  }

  async checkImage(file: UploadedFile) {
    return this.postFile('/v1/image/check', file);
  }

  async inspectUrl(url: string) {
    return this.postJson('/v1/url/inspect', { url });
  }

  async scanMessage(text: string, source: string) {
    return this.postJson('/v1/message/scan', { text, source });
  }
}

export const aiClient = new AiClient();