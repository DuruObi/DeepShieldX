import { Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

export interface AuthenticatedRequest extends Request {
  clientId?: string;
  headers: any;
  file?: any;
  body: any;
}

export const apiKeyAuth = async (req: AuthenticatedRequest, res: any, next: any) => {
  const apiKeyHeader = req.headers['x-api-key'];
  // Handle case where header could be string[]
  const apiKey = Array.isArray(apiKeyHeader) ? apiKeyHeader[0] : apiKeyHeader;

  if (!apiKey) {
    return res.status(401).json({ error: 'API Key missing' });
  }

  // Development Bypass
  if (apiKey === process.env.DEV_API_KEY) {
    req.clientId = 'DEV_USER';
    return next();
  }

  try {
    const result = await pool.query('SELECT client_id FROM api_keys WHERE key_value = $1 AND is_active = true', [apiKey]);
    
    if (result.rows.length > 0) {
      req.clientId = result.rows[0].client_id;
      next();
    } else {
      res.status(403).json({ error: 'Invalid API Key' });
    }
  } catch (error) {
    console.error('DB Auth Error', error);
    res.status(500).json({ error: 'Authentication service unavailable' });
  }
};